# ♞ Aldy Saleh Catur — Play. Think. Win.

Aplikasi catur berbasis web dengan tampilan modern, responsif, dan fitur permainan yang variatif. Dibuat menggunakan HTML, CSS, JavaScript, dan [chess.js](https://github.com/jhlywa/chess.js).

![Aldy Saleh Catur](https://img.shields.io/badge/Game-Chess%20Royale-e7b75b?style=for-the-badge)
![HTML](https://img.shields.io/badge/HTML-5-orange)
![CSS](https://img.shields.io/badge/CSS-3-blue)
![JavaScript](https://img.shields.io/badge/JavaScript-Vanilla-yellow)
![License](https://img.shields.io/badge/License-MIT-green)

## ✨ Features

- **Interactive chessboard** — pilih bidak dan lihat langkah legal.
- **Play vs AI** — tiga pilihan tingkat kesulitan (Easy, Medium, Hard*).
- **Local multiplayer** — bermain bergantian pada satu perangkat.
- **Move history** — riwayat langkah dalam notasi catur.
- **Captured pieces** — ringkasan bidak yang tertangkap.
- **Undo & New Game** — kontrol permainan praktis.
- **Flip board** — balik orientasi papan.
- **Board themes** — Classic Green, Warm Wood, Ocean Blue, dan Mint Garden.
- **Optional timer** — tanpa timer, 5, 10, atau 15 menit.
- **Responsive design** — nyaman digunakan di desktop maupun ponsel.

> *Hard mode menggunakan heuristik penilaian langkah sederhana, bukan engine catur profesional seperti Stockfish.*

## 🚀 Run locally

1. Download atau clone repository:
   ```bash
   git clone https://github.com/USERNAME/Chess-App.git
   ```
2. Buka folder project.
3. Jalankan `index.html` di browser.

Tidak perlu instalasi package atau server backend. Koneksi internet diperlukan untuk memuat library `chess.js` dari CDN.

## 🌐 Publish with GitHub Pages

1. Push seluruh file project ke repository GitHub.
2. Buka **Settings → Pages**.
3. Pada **Build and deployment**, pilih **Deploy from a branch**.
4. Pilih branch `main` dan folder `/ (root)`, lalu klik **Save**.
5. Tunggu proses deployment. Website akan tersedia pada alamat GitHub Pages repository kamu.

## 📓 Google Colab

Notebook `Aldy_Saleh_Catur_Google_Colab.ipynb` disediakan sebagai versi untuk dibuka di Google Colab. Buka Colab, pilih **File → Upload notebook**, lalu upload notebook tersebut.

## 🧰 Tech stack

- HTML5
- CSS3 (responsive layout and themes)
- Vanilla JavaScript
- chess.js 0.10.3 (legal move validation and game state)

## 📁 Project structure

```text
Chess-App/
├── index.html
├── Aldy_Saleh_Catur_Google_Colab.ipynb
├── README.md
├── LICENSE
└── .gitignore
```

## 📌 Notes

- Promosi pion otomatis menjadi ratu.
- AI berjalan sebagai bidak hitam saat mode **Play vs AI** aktif.
- Timer adalah fitur lokal pada browser dan tidak disinkronkan antar perangkat.
- Game ini merupakan project pembelajaran dan hiburan, bukan platform kompetisi online.

## 📄 License

Distributed under the MIT License. See `LICENSE` for details.
